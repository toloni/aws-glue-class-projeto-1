import logging
from pyspark.sql import DataFrame
from pyspark.sql.functions import col


class ProcessingLogger:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.stats = {}

    def log_info(self, message: str):
        self.logger.info(message)

    def log_error(self, message: str, exc_info=True):
        self.logger.error(message, exc_info=exc_info)

    def log_status_count(self, df: DataFrame):
        """
        Loga a quantidade de registros no DataFrame por status.
        """
        try:
            status_count = df.groupBy("status").count().collect()
            self.stats = {row["status"]: row["count"] for row in status_count}
            for status, count in self.stats.items():
                self.logger.info(f"Status: {status}, Quantidade: {count}")
        except Exception as e:
            self.logger.error(f"Erro ao calcular estatísticas de status: {str(e)}")

    def get_stats(self):
        """
        Retorna as estatísticas coletadas.
        """
        return self.stats
