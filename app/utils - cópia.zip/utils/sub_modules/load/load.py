def transform(df_encart_pj, df_cache_dict, base):

    pass
